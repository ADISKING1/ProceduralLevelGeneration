This is the prototype of the procedural level generation model
Every time you complete the game you are provides you with a different layout.

This might not be fun now, I'll tryna improve.